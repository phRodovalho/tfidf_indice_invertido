 
# Estrutura de índice invertido baseado no modelo vetorial tf-idf

Este repositório referente a organização e recuperação de informação, trabalho tem por objetivo construção de uma estrutura de índice invertido baseado no modelo vetorial tf-idf

## Visão sobre o algoritmo implementado

![Fluxograma](https://github.com/phRodovalho/busca_booleana_indice_invertido/blob/main/Fluxograma-algoritmo-busca-booleana.png)

## Download e execução

### Download do Python no ambiente Linux:
  ### > Instale o Python 3 no Linux pelo comando: sudo apt install python3. 
  ### > Não é necessário nenhuma instalação de pacote específico, pois o import os é nativo.
  
### Para executar no ambiente Linux:
  ### > Abra o terminal e vá na pasta na qual estão os arquivos.
  ### > Execute o comando python para rodar o arquivo. 
